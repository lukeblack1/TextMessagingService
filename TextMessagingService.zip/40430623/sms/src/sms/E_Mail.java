/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms;

/**
 *
 *  40430623
 */


import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class E_Mail extends javax.swing.JFrame {

    /**
 
     * 
     * 
     *
     */
    public E_Mail() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        number = new javax.swing.JTextField();
        send = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        message = new javax.swing.JTextArea();
        Text = new javax.swing.JTabbedPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        Textfield1 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        Text2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        text5 = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        Tweet = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Email:");

        send.setText("send");
        send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendActionPerformed(evt);
            }
        });

        message.setColumns(20);
        message.setRows(5);
        jScrollPane1.setViewportView(message);

        jTabbedPane1.addTab("Current Message", jScrollPane1);

        Textfield1.setColumns(20);
        Textfield1.setRows(5);
        jScrollPane2.setViewportView(Textfield1);

        Text.addTab("tab1", jScrollPane2);

        jTabbedPane1.addTab("Previous Message", Text);

        jLabel2.setText("MessID");

        jLabel4.setText("Subject");

        text5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                text5ActionPerformed(evt);
            }
        });

        jMenu1.setText("Menu");
        jMenu1.setToolTipText("");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        Tweet.setText("Tweet");
        Tweet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TweetActionPerformed(evt);
            }
        });
        jMenu1.add(Tweet);

        jMenuItem2.setText("E_Mail");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Text");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(send))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(number, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(Text2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(text5)))))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Text2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(text5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(send)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendActionPerformed
      //SMS send = new SMS();
     //send.SendSMS("lukeblack12", "lukeblack12!", message.getText(), number.getText(), "http://bulksms.2way.co.za/eapi/submission/send_sms/2/2.0/FFC45D215A304CED8403B1950A432778-02-4/FyaNJrsHwdZajSHxiTJcOxrwqKQgs");
            
         
     Text2.setText("S123456789");
         
       
      if (text5.getText().contains("Theft of Properties"))
      {
      
   FileWriter4();
      }
      
       if (text5.getText().contains("Staff Attack"))
      {
      
   FileWriter4();
      }
       
        if (text5.getText().contains("Device Damage"))
      {
      
   FileWriter4();
      }
        
          if (text5.getText().contains("Raid"))
      {
      
   FileWriter4();
      }
            if (text5.getText().contains("Customer Attack"))
      {
      
   FileWriter4();
      }
              if (text5.getText().contains("Staff Abuse"))
      {
      
   FileWriter4();
      }
                if (text5.getText().contains("Bomb threat"))
      {
      
   FileWriter4();
      }
                  if (text5.getText().contains("Terrorism"))
      {
      
   FileWriter4();
      }
                    if (text5.getText().contains("Suspicous Incident"))
      {
      
   FileWriter4();
      }
                      if (text5.getText().contains("Sport Injury"))
      {
      
   FileWriter4();
      }
                        if (text5.getText().contains("Personal Info Leak"))
      {
      
   FileWriter4();
      }
        
        if ((message.getText().length()) > 1028)  {
     
               JOptionPane.showMessageDialog(null,"Error: Please enter message less than 1028");
               
         
           }else{ 
               
        JOptionPane.showMessageDialog(null,"message Sent!");
        
          if (message.getText().contains("http"))
      {
        message.removeAll();
        message.setText("<URL Quarantined>");
        FileWriter3();
      }
          
        FileWriter1();    
        FileWriter2();
           }
           
    
           
        
           
           
    }//GEN-LAST:event_sendActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
     
       
        new sms().setVisible(true);
    }//GEN-LAST:event_jMenu1ActionPerformed

    private void TweetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TweetActionPerformed
new sms().setVisible(true);
    }//GEN-LAST:event_TweetActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
         new E_Mail().setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        new Text().setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void text5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_text5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_text5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new E_Mail().setVisible(true);
            }
        });
    }


    private void FileWriter1() {
       try {
         BufferedWriter out = new BufferedWriter(new FileWriter("outfilenameEmail.JSON"));
         out.write(number.getText());
         out.write(message.getText());
         out.close();
         System.out.println("JSON File created successfully");
      }
      catch (IOException e) {
      }
   }
    
    private void FileWriter2() {
       try {
         BufferedWriter out = new BufferedWriter(new FileWriter("outfilenameEmail.txt"));
         out.write(number.getText());
         out.write(message.getText());
         out.close();
           System.out.println("TXT file Created");
      }
      catch (IOException e) {
      }
   }
    private void FileWriter3() {
       try {
         BufferedWriter out = new BufferedWriter(new FileWriter("Quarenteen.JSON"));
         
         out.write(number.getText());
         out.write(message.getText());
         out.close();
         System.out.println("File Quarenteened");
      }
      catch (IOException e) {
      }
   }
     private void FileWriter4() {
       try {
         BufferedWriter out = new BufferedWriter(new FileWriter("SIRLIST.JSON"));
         
         out.write(text5.getText());
         
         out.close();
         System.out.println("File sent to SirList"+ "\n "+ "26-666-99" +text5.getText());
           
      }
      catch (IOException e) {
      }
     }
    private void FileReader() 
    {
  
    String fname;
    Scanner scan = new Scanner(System.in);

    /* enter filename with extension to open and read its content */

    System.out.print("Enter File Name to Open (with extension like file.txt) : ");
    fname = scan.nextLine();

    /* this will reference only one line at a time */

    String line = null;
    try
    {
        /* FileReader reads text files in the default encoding */
        FileReader fileReader = new FileReader(fname);

        /* always wrap the FileReader in BufferedReader */
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        while((line = bufferedReader.readLine()) != null)
        {
            System.out.println(line);
        }

        /* always close the file after use */
        bufferedReader.close();
    }
    catch(IOException ex)
    {
        System.out.println("Error reading file named '" + fname + "'");
    }
}

    private void FileReader2(String outfilenametxt) {
       
   {
    JFileChooser fc = new JFileChooser();
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    JTextArea tarea = new JTextArea(10, 10);

    JButton readButton = new JButton("OPEN FILE");
    readButton.addActionListener(ev -> {
      int returnVal = fc.showOpenDialog(frame);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
        File file = fc.getSelectedFile();
        try {
          BufferedReader input = new BufferedReader(new InputStreamReader(
              new FileInputStream(file)));
          tarea.read(input, "READING FILE :\"outfilename.txt\"-)");
        } catch (Exception e) {
          e.printStackTrace();
        }
      } else {
        System.out.println("Operation is CANCELLED :(");
      }
    });

    frame.getContentPane().add(tarea, BorderLayout.CENTER);
    frame.getContentPane().add(readButton, BorderLayout.PAGE_END);
    frame.pack();
    frame.setVisible(true);
  }
    }
    
    public class CSVReaderInJava {
 {

        String csvFile = "E:/1. University/2. Software Engineering/Assessments/Quarenteen.txt";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null ) {

                // use comma as separator
                String[] country = line.split(cvsSplitBy);
                
                 System.out.println("Abbreviations [code= " + country[0] + " , Abbreviation=" + country[1] + "]");
               
                }
            

        } catch (IOException e) {
        }

 }
 
    }

    

    

    
    


    

    
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Text;
    private javax.swing.JTextField Text2;
    private javax.swing.JTextArea Textfield1;
    private javax.swing.JMenuItem Tweet;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea message;
    private javax.swing.JTextField number;
    private javax.swing.JButton send;
    private javax.swing.JTextField text5;
    // End of variables declaration//GEN-END:variables
}
