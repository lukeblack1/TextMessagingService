/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms;

/**
 *
 * @author 40430623
 */
import java.io.*;

public class FileWriters {
   public static void main(String[] args) {
      try {
         BufferedWriter out = new BufferedWriter(new FileWriter("outfilename"));
         out.write("aString");
         out.close();
         System.out.println("File created successfully");
      }
      catch (IOException e) {
      }
   }

    static void main(String line) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}